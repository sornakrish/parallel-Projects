import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddmountComponent } from './addmount/addmount.component';
import { HomeComponent } from './home/home.component';
import { ViewaccountComponent } from './viewaccount/viewaccount.component';
import { ViewallaccountComponent } from './viewallaccount/viewallaccount.component';
import { MoneytransferComponent } from './moneytransfer/moneytransfer.component';
import { AccountcreationComponent } from './accountcreation/accountcreation.component';
// import { FilterPipe } from './filter.pipe';
import { filter } from '../app/filter.pipe';
import { WithdrawComponent } from './withdraw/withdraw.component';

@NgModule({
  declarations: [
    AppComponent,
    AddmountComponent,
    HomeComponent,
    ViewaccountComponent,
    ViewallaccountComponent,
    MoneytransferComponent,
    AccountcreationComponent,
    filter,
    WithdrawComponent
    // FilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
