import { Component, OnInit } from '@angular/core';
import data from '../../data/accountdetails.json';
@Component({
  selector: 'app-viewaccount',
  templateUrl: './viewaccount.component.html',
  styleUrls: ['./viewaccount.component.css']
})
export class ViewaccountComponent implements OnInit {
  array=data
  flag=false
  constructor() { }

  ngOnInit() {
  }
  setFlag()
  {
    this.flag=true
  }
}
