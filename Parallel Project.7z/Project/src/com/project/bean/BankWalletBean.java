package com.project.bean;

import java.util.Random;

public class BankWalletBean {
	private String name;
	private long accNo,mobNo;
	private float balance,depAmount,withdrawAmount,transferAmount;
	private long sourceAccNo,destAccNo;
	private String transactions;
	
	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public float getDepAmount() {
		return depAmount;
	}

	public void setDepAmount(float depAmount) {
		this.depAmount = depAmount;
	}
	
	public void setTranid(int transId)
	{
		ran(1000,1999);
	}

	private Object ran(int min, int max) {
		Random r=new Random();
		return r.nextInt((max-min)+1)+min;
	}

	public float getWithdrawAmount() {
		return withdrawAmount;
	}

	public void setWithdrawAmount(float withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public long getMobNo() {
		return mobNo;
	}

	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(double amt) {
		this.balance = (float) amt;
	}

	public BankWalletBean(long accNo, String name, long mobNo, float balance) {
		this.name=name;
		this.accNo=accNo;
		this.mobNo=mobNo;
		this.balance=balance;
	}

	public BankWalletBean(long accNo) {
		this.accNo=accNo;
	}

	public BankWalletBean(float withdrawAmount, long accNo) {
		this.withdrawAmount=withdrawAmount;
		this.accNo=accNo;
	}

	public BankWalletBean(long accNo, float depAmount) {
		this.depAmount=depAmount;
		this.accNo=accNo;	
	}

	public BankWalletBean(long sourceAccNo, long destAccNo, float transferAmount) {
		this.sourceAccNo=sourceAccNo;
		this.destAccNo=destAccNo;
		this.transferAmount=transferAmount;
	}

	public float getTransferAmount() {
		return transferAmount;
	}

	public void setTransferAmount(float transferAmount) {
		this.transferAmount = transferAmount;
	}

	public long getSourceAccNo() {
		return sourceAccNo;
	}

	public void setSourceAccNo(long sourceAccNo) {
		this.sourceAccNo = sourceAccNo;
	}

	public long getDestAccNo() {
		return destAccNo;
	}

	public void setDestAccNo(long destAccNo) {
		this.destAccNo = destAccNo;
	}

	
}
