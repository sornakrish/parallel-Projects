package com.cg.bank.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

 
//using jpa 
@Table(name="transaction")
@Entity
public class Transaction { 

    @Column(name="id")
    @Id
    @GeneratedValue
    int id;
    @Column(name="accnum")
    int accnum;
    @Column(name="msg")
    String msg;   
    
    @Override
	public String toString() {
		return "Transaction [id=" + id + ", accnum=" + accnum + ", msg=" + msg + "]";
	}
	public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
   
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Transaction(int id, int accnum, String msg) {
        super();
        this.id = id;
        this.accnum = accnum;
        this.msg = msg;
    }
    
    public int getAccnum() {
		return accnum;
	}
	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}
	public Transaction() {
        
    }
    
}