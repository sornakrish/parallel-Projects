package com.cg.bank.dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.bank.bean.Bank;

@Repository
public interface BankDao extends JpaRepository<Bank, Integer>{

//	@Query("from Bank where username=:username")
//	boolean getUsernameByLogin(String username);
//
//	@Query("from Bank where password=:password")
//	boolean getPasswordByLogin(String password);
//	
	
}
