package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Bank;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.IBankService;
import com.cg.bank.service.TransactionService;


@CrossOrigin(origins="http://localhost:4200")
@RestController

public class BankController {

	@Autowired
	IBankService bankService;
	@Autowired
	TransactionService transactionService;
	
	@RequestMapping(value="/bank",method=RequestMethod.POST)
	public List<Bank> addBank(@RequestBody Bank bank) throws BankException{
		return bankService.addBank(bank);
	}
	@RequestMapping("/bank")
	public List<Bank> getBankDetails() throws BankException{
		return bankService.getAllBankDetials();
	}
	
	@RequestMapping(value="/showbalance/{accountnum}",method=RequestMethod.GET)
	public int getBankDetailsByAccountnum(@PathVariable int accountnum) throws BankException{
		return bankService.showBalance(accountnum);
	}
	
	@RequestMapping(value="/deposit/{accountnum}/{amount}",method=RequestMethod.PUT)
	public int depositMoney(@PathVariable int accountnum,@PathVariable int amount) throws BankException{
		transactionService.addTransaction("Amount "+amount+" deposited to your account",accountnum);
		return bankService.depositMoney(accountnum, amount);
	}
	
	@RequestMapping(value="/withdraw/{accountnum}/{amount}",method=RequestMethod.PUT)
	public int withdrawMoney(@PathVariable int accountnum,@PathVariable int amount) throws BankException{
		transactionService.addTransaction("Amount "+amount+" credited to your account",accountnum);
		return bankService.withdrawMoney(accountnum, amount);
	}
	
	@RequestMapping(value="/fundtransfer/{accountnum1}/{accountnum2}/{amount}",method=RequestMethod.PUT)
	public int fundTransfer(@PathVariable int accountnum1,@PathVariable int accountnum2,@PathVariable int amount) throws BankException{
		transactionService.addTransaction("Amount "+amount+" debited to your account",accountnum1);
		transactionService.addTransaction("Amount "+amount+" credited to your account",accountnum2);
		return bankService.fundTransfer(accountnum1,accountnum2, amount);
	}
	
	@RequestMapping(value="/transactions/all/{id}")
	public List<String> getTransaction(@PathVariable int id) throws BankException{
		return transactionService.getTransaction(id);
	}
	
//	@RequestMapping(value="/login/username/password",method=RequestMethod.PUT)
//	public Boolean getCustomerByLoginDetails(@PathVariable String username,@PathVariable String password) throws BankException{
//		return bankService.getCustomerByLoginDetails(username,password);
//	}
	
	
}
