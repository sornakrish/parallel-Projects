package com.springjpa.exceptions;

import java.util.Arrays;

public class InputMismatchException extends RuntimeException {
	public InputMismatchException(String message) {
		super(message);
	}

}
