package com.springjpa.exceptions;

public class NumberFormatException extends RuntimeException{
	public NumberFormatException(String message) {
		super(message);
	}
}
