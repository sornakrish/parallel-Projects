//Collection DAO
package com.springjpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springjpa.beans.TransactionBeans;
import com.springjpa.beans.UserBeans;



@Repository("BankDAO")
public class ImplDAO implements InterfaceDAO{

	@PersistenceContext(name="persistance")
	EntityManager con;
	
	
	TransactionBeans tb;
	UserBeans cb = new UserBeans(), cb1 = new UserBeans();
	static int i = 0;

	@Override
	@Transactional
	public long setValue(String userName, long userNumber, String userDob, long userAccNo, String userPassword) {			//Creating new User

		cb = new UserBeans();
		cb.setUserBalance(25000.00);
		cb.setUserDob(userDob);
		cb.setUserName(userName);
		cb.setUserNumber(userNumber);
		cb.setUserPassword(userPassword);
		cb.setUserAccNo(userAccNo);
		//System.out.println(cb.getUserAccNo()+"\n"+userName+"\n"+userDob+"\n"+userNumber+"\n"+userPassword+"\n"+userAccNo);
//		System.out.println(con);
		con.persist(cb);

		
		tb = new TransactionBeans();
		String str = "Account No " + userAccNo + " is Created.";
		tb.setTransaction(str);
		tb.setUb(cb);
		
		con.persist(tb);
		
		
		return userAccNo;
	}

	@Override
	@Transactional
	public boolean checkAccount(long accNo, String password) {
		cb = con.find(UserBeans.class, new Long(accNo));
		if(cb.getUserAccNo()==accNo && password.equals(cb.getUserPassword())) {
			return true;
		}
		return false;
	}

	@Override
	@Transactional
	public double setWithdraw(double amount, long accNo) {
		cb = con.find(UserBeans.class, new Long(accNo));
		tb = new TransactionBeans();
		Double tempAmount = cb.getUserBalance();
		cb.setUserBalance(tempAmount-amount);
		String tempTrans = "Amount Rs."+ amount + " withdrawn from Account No " + accNo + "." ;
		tb.setTransaction(tempTrans);
		tb.setUb(cb);
		con.persist(tb);

		return amount;
	}

	@Override
	@Transactional
	public double setDeposit(double amount, long accNo) {
		cb = con.find(UserBeans.class, new Long(accNo));
		tb = new TransactionBeans();
		Double tempAmount = cb.getUserBalance();
		cb.setUserBalance(tempAmount+amount);
		String tempTrans = "Amount Rs."+ amount + " deposited to Account No " + accNo + "." ;
		tb.setTransaction(tempTrans);
		tb.setUb(cb);
		con.persist(tb);

		return amount;
	}

	@Override
	@Transactional
	public UserBeans showAccount(long accNo) {
		cb = con.find(UserBeans.class, new Long(accNo));

		return cb;
	}

	@Override
	@Transactional
	public int setTransfer(long accNo1, long accNo2, float amount) {
		cb = con.find(UserBeans.class, new Long(accNo1));
		tb = new TransactionBeans();
		cb1 = con.find(UserBeans.class, new Long(accNo2));
		
		Double tempAmount = cb.getUserBalance();
		Double tempAmount1 = cb1.getUserBalance();
		cb.setUserBalance(tempAmount-amount);
		cb1.setUserBalance(tempAmount1+amount);
		String tempTrans = "Amount Rs."+ amount + " transfered from Account No. "+ accNo1 + " to Account No " + accNo2 + "." ;
		tb.setTransaction(tempTrans);
		tb.setUb(cb);
		con.persist(tb);
		
		tb = new TransactionBeans();
		tb.setTransaction(tempTrans);
		tb.setUb(cb1);
		con.persist(tb);
		return 1;
	}

	@Override
	@Transactional
	public List<TransactionBeans> showTransaction(long accNo) {
//		tb = new TransactionBeans();
//		tb = con.find(TransactionBeans.class, new Long(accNo));
		
		TypedQuery<TransactionBeans> query = (TypedQuery<TransactionBeans>) con.createQuery("SELECT t FROM TransactionBeans t WHERE AccountNo=?1").setParameter(1, accNo); 
		List<TransactionBeans> list = query.getResultList();
//		System.out.println(list);

		return list;
	}

}
