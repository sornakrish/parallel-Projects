//Collection DAO Interface
package com.springjpa.dao;

import java.util.*;

import com.springjpa.beans.TransactionBeans;
import com.springjpa.beans.UserBeans;


public interface InterfaceDAO{
	long setValue(String userName, long userNumber, String userDob, long userAccNo, String userPassword);
	boolean checkAccount(long accNo, String password);
	double setWithdraw(double amount, long accNo) ;
	double setDeposit(double amount, long accNo);
	UserBeans showAccount(long accNo);
	int setTransfer(long accNo1, long accNo2, float amount);
	List<TransactionBeans> showTransaction(long accNo);
}
