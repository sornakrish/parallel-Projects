//User Interface
package com.springjpa.ui;



import java.util.Random;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springjpa.beans.UserBeans;
import com.springjpa.server.ImplService;
import com.springjpa.server.InterfaceService;


public class UserUI {
	static Scanner sc = new Scanner(System.in);
	static UserBeans cb = new UserBeans();

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		InterfaceService cs=context.getBean("BankService",ImplService.class);
		String userName = null, userDob = null, userPassword, userNumber1;
		int n = 0;
		long userAccNo, userNumber;
		boolean ck = false;

		while(true) {

			System.out.println("\n*************************Wallet********************************\n");

			//user input
			System.out.println("Enter 1 to Create Account -");
			System.out.println("Enter 2 to Withdraw money -");
			System.out.println("Enter 3 to Deposit money -");
			System.out.println("Enter 4 to show Balance -");
			System.out.println("Enter 5 for Fund Transfer -");
			System.out.println("Enter 6 to print Transactions -");
			System.out.println("Enter 7 to Exit :\n");
			System.out.print("Enter Your Choice :");
			n = sc.nextInt();

			switch(n) {

			case 1:
				//create new user account
				System.out.print("\nEnter your Name :" );
				userName = sc.next();
				if(cs.checkName(userName)==false) {													//validate userName
					System.out.println("\nFirst Letter Should be Capital");
					break;
				}

				System.out.print("\nEnter your mobile number :");
				userNumber1 = sc.next();
				
				if(cs.checkNumber(userNumber1)==false) {
					break;
				}
				else {
					ck = true;
				}

				System.out.print("\nEnter your Date Of Birth(dd/mm/yyyy) :");
				userDob = sc.next();
				if(cs.checkDob(userDob)==false) {													 //validate user Date Of Birth
					break;
				}


				System.out.print("\nEnter Password for your Account :");
				userPassword = sc.next();
				if(cs.checkPassword(userPassword)==false) {													 //validate user Password
					break;
				}

				Random rand = new Random();
				userAccNo = rand.nextInt(900000000) + 900000000;

				userNumber = Long.parseLong(userNumber1);
				System.out.println("\nAccount Created with Account Number "+ cs.setBeans(userName, userNumber, userDob, userAccNo, userPassword));

				break;


			case 2:
				//withdraw money from existed account

				System.out.print("\nEnter account number :");
				long accNo2 = sc.nextLong();
				if(cs.checkAccount(accNo2) == false) {						 								//validate user Account Number
					break;
				}
				System.out.print("\nEnter password :");
				String password2 = sc.next();
				if(cs.checkPassword(password2) == false) {													 //validate user Password
					break;
				}
				if(cs.check(accNo2, password2) == false) {					  								//check if account no and password matches
					System.out.println("\nWrong Information Entered.\nCheck Account Number and Password\n");
					break;
				}

				System.out.print("Enter amount you want to withdraw :");
				double withdrawAmount = cs.withdraw(sc.nextDouble(), accNo2);			 					//withdraw method call

				if(withdrawAmount>0) {
					System.out.println("Withdrawal of "+ withdrawAmount +" Successful");
				}
				else {
					System.out.println("Wrong Information.");
				}

				break;

			case 3:
				//Deposit money

				System.out.print("\nEnter account number :");
				long accNo3 = sc.nextLong();
				if(cs.checkAccount(accNo3)==false) {						 						    //validate user Account Number
					break;
				}

				System.out.print("\nEnter password :");
				String password3 = sc.next();						 		 							//validate user Password
				if(cs.checkPassword(password3)==false) {
					break;
				}

				if(cs.check(accNo3, password3) == false) {													//check if account no and password matches
					System.out.println("\nWrong Information Entered.\nCheck Account Number and Password\n");
					break;
				}

				System.out.print("\nEnter amount you want to deposit :");
				double depositAmount = cs.deposit(sc.nextDouble(), accNo3);				 								//deposit amount method call

				if(depositAmount>0) {
					System.out.println("\nDeposited "+ depositAmount + " rs. to your Account.");
				}
				else {
					System.out.println("Wrong Information.");
				}

				break;


			case 4:
				//Account Information

				System.out.print("\nEnter account number :");
				long accNo4 = sc.nextLong();					 												//validate user Account Number
				if(cs.checkAccount(accNo4)==false) {
					break;
				}

				System.out.print("\nEnter password :");
				String password4 = sc.next();
				if(cs.checkPassword(password4)==false) {					 									//validate user Password
					break;
				}

				if(cs.check(accNo4, password4) == false) {						 								//check user Account Number and password matches
					System.out.println("\nWrong Information Entered.\nCheck Account Number and Password then try again.\n");
					break;
				}

				cb = cs.info(accNo4);						 													//fetching information of current user
				System.out.println( "Name" + "\t\tDate Of Birth" + "\t\tMobile Number" 
									+ "\t\tAccount Number" + "\t\tBalance" +"\n");

				System.out.println( cb.getUserName() + "\t\t"+ cb.getUserDob() 
									+ "\t\t" + cb.getUserNumber() + "\t\t" + cb.getUserAccNo() 
									+ "\t\t" + cb.getUserBalance() + "\t\t" +"\n");

				break;

			case 5:
				//transfer amount to another account

				System.out.print("Enter your Account number :");
				long accNo51 = sc.nextLong();
				if(cs.checkAccount(accNo51)==false) {					 				//validate first user Account Number
					break;
				}

				System.out.print("\nEnter Password :");
				String password51 = sc.next();	 			
				if(cs.checkPassword(password51)==false) {								//validate first user Password
					break;
				}

				if(cs.check(accNo51, password51) == false) {						 	//check if first user Account Number and Password matches
					System.out.println("\nWrong Information Entered.\nCheck Account Number and Password then try again.\n");
					break;
				}

				System.out.print("\nEnter other user Account number :");
				long accNo52 = sc.nextLong();
				if(cs.checkAccount(accNo52)==false) {										  //validate second user Account Number
					break;
				}
				if(accNo52==accNo51) {
					System.out.println("\nSame Account Number Entered. ");
					break;
				}

				System.out.print("\nEnter amount to transfer :");

				if(cs.transfer(accNo51, accNo52, sc.nextFloat())==1) {									   //call to transfer method
					System.out.println("Fund Transfer Succesful.");
				}

				break;

			case 6:
				//show user transactions
				System.out.print("\nEnter account number:");
				long accNo6 = sc.nextLong();
				if(cs.checkAccount(accNo6)==false) {				 							  //validate user Account Number
					break;
				}

				System.out.print("\nEnter password :");
				String password6 = sc.next();
				if( cs.checkPassword(password6)==false) {										   //validate user Password
					break;
				}
				else {
					ck = true;
				}

				if(cs.check(accNo6, password6) == false) {						    			   //check if user Account Number and Password matches
					System.out.println("\nWrong Information Entered.\nCheck Account Number and Password then try again.\n");
					break;
				}
				System.out.println( cs.transactions(accNo6));				 						//call transaction method
				break;

			case 7:
				System.out.println("\n***************************************************************\n");
				System.out.println("\nTHANK YOU!\nPlease Visit Again.\n");
				System.exit(0);																		//Exit Here
				break;
			default:
				System.out.println("Entered wrong choice.\nEnter Again.\n");
			}
		}
	}
}
