//Collection Beans
package com.springjpa.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BankAccount")
public class UserBeans {
	//Private Variable declaration
	@Column(name="Name")
	private String userName;
	@Column(name="BirthDate")
	private String userDob;
	@Column(name="Password")
	private String userPassword;
	@Column(name="Balance")
	private double userBalance;
	@Id
	@Column(name="AccountNo")
	private long userAccNo;
	@Column(name="Mobile")
	private long userNumber;
	
	

	public UserBeans() {
	}
	public UserBeans(double userBalance, long userAccNo) {
		this.userBalance = userBalance;
		this.userAccNo = userAccNo;
	}
	// Getter And Setter Methods
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserDob() {
		return userDob;
	}
	public void setUserDob(String userDob) {
		this.userDob = userDob;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public long getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(long userNumber) {
		this.userNumber = userNumber;
	}
	public Double getUserBalance() {
		return userBalance;
	}
	public void setUserBalance(Double userBalance) {
		this.userBalance = userBalance;
	}
	public long getUserAccNo() {
		return userAccNo;
	}
	public void setUserAccNo(long userAccNo) {
		this.userAccNo = userAccNo;
	}
	@Override
	public String toString() {
		return "UserBeans [userName=" + userName + ", userDob=" + userDob + ", userPassword=" + userPassword
				+ ", userBalance=" + userBalance + ", userAccNo=" + userAccNo + ", userNumber=" + userNumber + "]";
	}

}
